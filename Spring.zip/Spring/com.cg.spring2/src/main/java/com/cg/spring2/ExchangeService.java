package com.cg.spring2;


public interface ExchangeService {

	public double getExchangeRate();
}
