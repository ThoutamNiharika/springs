package com.cg.spring2;

public interface CurrencyConverter {
	public double dollarToRupees(double dollars);
}
