package com.cg.spring2;


public class CurrencyConverterImpl implements CurrencyConverter {

	private ExchangeService exchangeService;

	public ExchangeService getExchangeService() {
		System.out.println("getExchangeService()");
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		System.out.println("setExchangeService()");
		this.exchangeService = exchangeService;
	}

	public CurrencyConverterImpl() {

		System.out.println("CurrencyConverterImpl");

	}

	public double dollarToRupees(double dollars) {
		System.out.println("dollarToRupees");
		return dollars * exchangeService.getExchangeRate();
	}

}
