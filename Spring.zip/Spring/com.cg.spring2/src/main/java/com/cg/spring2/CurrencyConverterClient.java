package com.cg.spring2;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CurrencyConverterClient {
	public static void main(String[] args) {
		
		ApplicationContext factory = new ClassPathXmlApplicationContext("currencyconverter.xml");
		CurrencyConverter curr = (CurrencyConverter) factory.getBean("currencyConverter");
		double rupees = curr.dollarToRupees(40.0);
		System.out.println("40 $ is "+rupees+"Rs.");
	}
}











